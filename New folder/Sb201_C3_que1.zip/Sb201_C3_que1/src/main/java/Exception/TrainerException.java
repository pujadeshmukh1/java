package Exception;

public class TrainerException extends Exception{
public TrainerException() {
		
	}
	
	
public TrainerException(String msg) {
		super(msg);
	}
}
