package Exception;

public class GymExcpetion extends Exception{

public GymExcpetion() {
		
	}
	
	
public GymExcpetion(String msg) {
		super(msg);
	}
	
}
