package com.masai.usecases;

public class registerPerson {

}
