package B;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		A a1= new A();
		B b1 = new B();
		c c1 = new c();
		
		a1.start();
		b1.start();
		c1.start();

	}

}
