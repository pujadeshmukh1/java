package com.masai;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sb201C4Que2Application {

	public static void main(String[] args) {
		SpringApplication.run(Sb201C4Que2Application.class, args);
	}

}
