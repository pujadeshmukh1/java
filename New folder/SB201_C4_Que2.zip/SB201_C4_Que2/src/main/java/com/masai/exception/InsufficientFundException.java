package com.masai.exception;

public class InsufficientFundException extends Exception {
	
	public InsufficientFundException(){
		
	}
	public InsufficientFundException(String msg){
		super(msg);
	}

}
