package ques2;

public class Main {

	public static void main(String[] args) {
		X x=Integer::parseInt;
		System.out.println(x.convetStringToNumber("1000"));
	}
}
