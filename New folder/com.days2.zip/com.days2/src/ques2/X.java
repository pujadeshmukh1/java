package ques2;

public interface X {
	
	public int convetStringToNumber(String s);
	
}
