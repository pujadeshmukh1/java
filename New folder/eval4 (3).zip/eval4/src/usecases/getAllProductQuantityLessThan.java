package usecases;

import java.util.Scanner;

import com.masai.ProductDaoImpl;
import com.masai.productDao;

public class getAllProductQuantityLessThan {

public static void main(String[] args) {
		
//		Scanner sc = new Scanner(System.in);
//		
//		System.out.println("Enter quantity :");
//		int quantity= sc.nextInt();
//
//		productDao dao = new ProductDaoImpl();
		
		
//		int quant= dao.getAllProductQuantityLessThan(quantity);
//		
//		if(quant >= 0)
//			System.out.println("quant is :"+quant);
//		else
//			System.out.println("product does not exist with Roll :"+quantity);
//		
		
	}
	
}
