package A;

public class B extends Thread{
	///
	public void run(){
	System.out.println("inside run() in B Classs Thread");
	}
	
	public static void main(String[] args) {
		//B b1=new B();
		
		//b1.start();//here second thread will start
	
//	for(int i=25;i<60;i++){
//		 
//		System.out.println("inside main mehod"+i);
//		 
//	}
	
	//System.out.println("end of main()..");

	
}
}