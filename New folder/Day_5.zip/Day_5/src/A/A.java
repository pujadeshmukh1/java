package A;

public class A implements Runnable{
	@Override
	public void run(){
	//define the taks which we want to execute as a thread
		System.out.println("inside run() in A Classs Runnable");
	}

	
	}

